package com.library.librarymanagementsystem.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.library.librarymanagementsystem.entities.Student;

public interface StudentRepository  extends  JpaRepository<Student,Integer> {

}
