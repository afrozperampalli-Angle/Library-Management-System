package com.library.librarymanagementsystem.controllers;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.library.librarymanagementsystem.entities.User;
import com.library.librarymanagementsystem.repositories.UserRepository;

@RestController
@RequestMapping("/admin")
@CrossOrigin(origins = "http://localhost:3000")
public class AdminAuthController {

    @Autowired
    private UserRepository userrepository;

    @PostMapping("/login")
    public ResponseEntity<String> login(@RequestBody User user) {

        boolean exists = userrepository.findByEmailAndPassword(
                user.getEmail(),
                user.getPassword()
        ).isPresent();

        return exists
                ? ResponseEntity.ok("SUCCESS")
                : ResponseEntity.status(401).body("INVALID");
        
    }
    @PostMapping("/register")
    public ResponseEntity<String> register(@RequestBody User user) {


        Optional<User> existing = userrepository.findByEmail(user.getEmail());

        if (existing.isPresent()) {
            return ResponseEntity.status(400).body("ADMIN_EXISTS");
        }

       
       userrepository.save(user);

        return ResponseEntity.ok("SUCCESS");
    }
}
