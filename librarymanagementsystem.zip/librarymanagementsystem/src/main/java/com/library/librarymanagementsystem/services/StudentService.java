package com.library.librarymanagementsystem.services;

import java.util.List;
import java.util.Optional;

import com.library.librarymanagementsystem.entities.Student;

public interface StudentService {
	Student createStudent(Student student);

    List<Student> getAllStudents();

    Optional<Student> getStudentById(int id);

    Student updateStudent(int id, Student student);

    void deleteStudent(int id);

}
