package com.library.librarymanagementsystem.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.library.librarymanagementsystem.entities.BookIssue;
import com.library.librarymanagementsystem.repositories.BookIssueRepository;

@Service
public class BookIssueServiceImp implements BookIssueService {

    @Autowired
    private BookIssueRepository repo;

    @Override
    public BookIssue saveIssue(BookIssue issue) {
        return repo.save(issue);
    }

    @Override
    public List<BookIssue> getAllIssues() {
        return repo.findAll();
    }

    @Override
    public BookIssue getIssueById(int id) {
        return repo.findById(id).orElse(null);
    }
    
    @Override
    public BookIssue updateIssue(int id, BookIssue issue) {
        BookIssue existing = repo.findById(id)
                .orElseThrow(() -> new RuntimeException("Issue not found"));

        existing.setIssueDate(issue.getIssueDate());
        existing.setReturnDate(issue.getReturnDate());
        existing.setRemarks(issue.getRemarks());
        existing.setStudent(issue.getStudent());
        existing.setBook(issue.getBook());

        return repo.save(existing);
    }


    @Override
    public void deleteIssue(int id) {
        repo.deleteById(id);
    }
}