package com.library.librarymanagementsystem.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.library.librarymanagementsystem.entities.Book;
import com.library.librarymanagementsystem.repositories.BookRepository;

@Service
public class BookServiceImp implements BookService {

    @Autowired
    private BookRepository repo;

    @Override
    public Book addBook(Book book) {
        return repo.save(book);
    }

    @Override
    public List<Book> getAllBooks() {
        return repo.findAll();
    }

    @Override
    public Book getBookById(int id) {
        return repo.findById(id).orElse(null);
    }

    @Override
    public Book updateBook(int id, Book updatedBook) {
        Book existing = repo.findById(id).orElse(null);
        if (existing == null) return null;

        existing.setTitle(updatedBook.getTitle());
        existing.setAuthor(updatedBook.getAuthor());
        existing.setImageUrl(updatedBook.getImageUrl());
        existing.setPublisher(updatedBook.getPublisher());
        existing.setCategory(updatedBook.getCategory());
        existing.setStock(updatedBook.getStock());

        return repo.save(existing);
    }

    @Override
    public void deleteBook(int id) {
        repo.deleteById(id);
    }
}