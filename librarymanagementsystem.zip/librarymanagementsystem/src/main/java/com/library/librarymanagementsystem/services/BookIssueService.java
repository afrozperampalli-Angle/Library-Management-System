package com.library.librarymanagementsystem.services;

import java.util.List;

import com.library.librarymanagementsystem.entities.BookIssue;

public interface BookIssueService {
	BookIssue saveIssue(BookIssue issue);

    List<BookIssue> getAllIssues();
    
    BookIssue updateIssue(int id, BookIssue issue);

    BookIssue getIssueById(int id);

    void deleteIssue(int id);

}
