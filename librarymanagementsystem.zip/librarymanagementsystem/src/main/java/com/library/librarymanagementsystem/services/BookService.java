package com.library.librarymanagementsystem.services;

import java.util.List;

import com.library.librarymanagementsystem.entities.Book;

public interface BookService {
	Book addBook(Book book);

    List<Book> getAllBooks();

    Book getBookById(int id);

    Book updateBook(int id, Book updatedBook);

    void deleteBook(int id);

}
