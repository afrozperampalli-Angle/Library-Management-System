package com.library.librarymanagementsystem.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.library.librarymanagementsystem.entities.Student;
import com.library.librarymanagementsystem.repositories.StudentRepository;

@Service
public class StudentServiceImp implements StudentService {

    @Autowired
    private StudentRepository studentrepository;

    @Override
    public Student createStudent(Student student) {
        return studentrepository.save(student);
    }

    @Override
    public List<Student> getAllStudents() {
        return studentrepository.findAll();
    }

    @Override
    public Optional<Student> getStudentById(int id) {
        return studentrepository.findById(id);
    }

    @Override
    public Student updateStudent(int id, Student student) {
        Optional<Student> existing = studentrepository.findById(id);

        if (existing.isPresent()) {
            Student s = existing.get();

            s.setStudentName(student.getStudentName());
            s.setEmail(student.getEmail());
            s.setPhone(student.getPhone());
            s.setAddress(student.getAddress());
            s.setJoiningDate(student.getJoiningDate());
            s.setRemarks(student.getRemarks());

            return studentrepository.save(s);
        }

        return null;
    }

    @Override  
    public void deleteStudent(int id) {
        studentrepository.deleteById(id);
    }
}