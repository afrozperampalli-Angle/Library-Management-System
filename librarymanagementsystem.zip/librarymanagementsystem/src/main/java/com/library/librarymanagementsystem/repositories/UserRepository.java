package com.library.librarymanagementsystem.repositories;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.library.librarymanagementsystem.entities.User;


public interface UserRepository extends JpaRepository<User,String>{
	Optional<User> findByEmailAndPassword(String email,String password);
	Optional<User> findByEmail(String email);
	

}
