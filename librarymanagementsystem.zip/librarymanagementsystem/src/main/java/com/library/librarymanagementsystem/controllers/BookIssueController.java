package com.library.librarymanagementsystem.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.library.librarymanagementsystem.entities.BookIssue;
import com.library.librarymanagementsystem.services.BookIssueService;

@RestController
@RequestMapping("/issues")
public class BookIssueController {

    @Autowired
    private BookIssueService service;

    @PostMapping("/add")
    public BookIssue addIssue(@RequestBody BookIssue issue) {
        return service.saveIssue(issue);
    }

    @GetMapping("/all")
    public List<BookIssue> getAll() {
        return service.getAllIssues();
    }

    @GetMapping("/{id}")
    public BookIssue getIssue(@PathVariable int id) {
        return service.getIssueById(id);
    }
    
    @PutMapping("/{id}")
    public BookIssue updateIssue(@PathVariable int id, @RequestBody BookIssue issue) {
        return service.updateIssue(id, issue);
    }


    @DeleteMapping("/delete/{id}")
    public String deleteIssue(@PathVariable int id) {
        service.deleteIssue(id);
        return "Deleted Successfully!";
    }
}