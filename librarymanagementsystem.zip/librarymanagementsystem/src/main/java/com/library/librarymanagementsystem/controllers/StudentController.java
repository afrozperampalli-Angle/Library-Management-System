package com.library.librarymanagementsystem.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.library.librarymanagementsystem.entities.Student;
import com.library.librarymanagementsystem.services.StudentService;

@RestController 
public class StudentController {
  @Autowired
  private StudentService   studentservice;
   
  @PostMapping("/students")
  public  Student  createStudent(@RequestBody Student  student) {
	  
	  return studentservice.createStudent(student);
   
	
} 
   @GetMapping("/students")
   public List<Student>  getAllStudents(){
	   
	 return  studentservice.getAllStudents();
   }
   
   @GetMapping("/students/{id}")
   public ResponseEntity<Student> getStudent(@PathVariable int id){
   
	    Student student=studentservice.getStudentById(id).orElse(null);
	    if  (student!=null) {
	    	return ResponseEntity.ok().body(student); 			
	    }else {
	    	return ResponseEntity.notFound().build();
	    }
   }
   
   @PutMapping("/students/{id}")
   public ResponseEntity<Student> updateStudent(@PathVariable int id,@RequestBody Student student ) {
	   Student updatestudent=studentservice.updateStudent(id, student);
	    if(updatestudent!=null) {
	    	return ResponseEntity.ok().body(updatestudent);
	    }else {
	    	return ResponseEntity.notFound().build();
	    }
} 
     @DeleteMapping("/students/{id}")
     public ResponseEntity<Void> deletestudent(@PathVariable int id){
    	 studentservice.deleteStudent(id);
    	 return ResponseEntity.noContent().build();
     }
}
