package com.library.librarymanagementsystem.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.library.librarymanagementsystem.entities.Book;

public interface BookRepository extends JpaRepository<Book,Integer> {

}
