package com.library.librarymanagementsystem.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.library.librarymanagementsystem.entities.BookIssue;

public interface BookIssueRepository extends JpaRepository<BookIssue,Integer>{

}
